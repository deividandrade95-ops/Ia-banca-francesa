# IA Banca Francesa V6.4

## Correção principal
- A escolha manual P/G é feita pelo utilizador na Betclic quando a IA não libera sinal.
- A escolha manual NÃO é contabilizada como entrada da IA.
- A auditoria de entradas mostra exclusivamente sinais reais liberados pela IA (P azul ou G verde).
- Sem sinal, o indicador central fica em AGUARDAR/amarelo, e não em P azul.
- O histórico continua sendo preservado; os campos `userChoice`/`choice` registram a escolha manual apenas para auditoria da rodada, sem transformá-la em sinal da IA.
- Entradas IA são identificadas por `aiSignal: G/P` e recebem stake IA separada.

## Segurança
A correção não transforma escolhas manuais em sinais e não altera resultados históricos para criar entradas. A lógica de liberação de sinais continua sujeita ao motor de calibração e ao limiar.
