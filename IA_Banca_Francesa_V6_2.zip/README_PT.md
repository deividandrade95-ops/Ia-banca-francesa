# IA Banca Francesa V6.2

Versão para auditoria e observação de 100 testes.

- Janela de observação: O3003 a O3102.
- AGUARDAR não recebe stake.
- Sem progressão após perdas.
- Histórico cruzado por número de teste, sem apagar registros existentes.
- Inclui os registros históricos recuperados e os resultados recentes confirmados nas telas disponíveis.
- Use Importar JSON para acrescentar outros históricos exportados das versões anteriores.

Coloque `index.html` diretamente na raiz do GitHub Pages.
