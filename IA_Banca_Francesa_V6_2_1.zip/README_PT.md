IA Banca Francesa V6.2.1

Correções principais:
- Referência correta das classes: G=4/17, P=7/17, N=6/17.
- Janela operacional O2903–O3202.
- Seleção de limiar com cobertura mínima adaptativa, evitando AGUARDAR indefinidamente.
- Walk-forward temporal, sem usar resultados futuros no treino.
- Preserva histórico local e permite exportar/importar JSON.

Importante: a versão não garante lucro nem prevê aleatoriedade com certeza. Serve para medir se existe sinal fora da amostra. Faça primeiro auditoria sem aumentar stake.
