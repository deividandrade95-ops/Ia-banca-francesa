IA Banca Francesa V6.3.2

Correções:
- O utilizador é obrigado a escolher P ou G em todas as rodadas.
- Existe um seletor manual P/G para as rodadas sem sinal.
- Sem sinal confirmado da IA, a escolha manual usa stake mínima de €0,50.
- Quando a IA libera G ou P, a escolha é o sinal da IA e a stake registada é maior (€5,00).
- Se o resultado real for N, o resultado é NEUTRO e não gera perda financeira.
- A auditoria financeira conta todas as escolhas P/G com stake, incluindo acertos, erros e neutros.
- Não há progressão de stake após perdas.

Substitua o conteúdo do index.html no GitHub.
