# IA Banca Francesa V6.2 — Auditoria Integral

Esta versão cruza os registros disponíveis das versões anteriores e os registros recentes visíveis.

- 389 registros exatos incorporados, sem preencher lacunas por estimativa.
- Auditoria de conflitos por número de teste.
- Walk-forward temporal sem vazamento de futuro.
- AGUARDAR = €0; sem progressão após perdas.
- Nova janela de observação: O3003–O3102 (100 testes).
- Antes de usar, exporte o JSON da versão atual e importe-o nesta versão para preservar qualquer registro local que não esteja no pacote.
