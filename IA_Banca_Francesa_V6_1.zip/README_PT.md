# IA Banca Francesa V6.1

Versão estrutural com preservação do histórico, merge por número, importação não destrutiva, walk-forward temporal, limiar selecionado em validação OOS, pesos de recência, suavização por transições, contexto de regimes, baselines e auditoria financeira.

Janela dos próximos testes: O2903–O3202 (300 testes).

Importante: a aplicação não inventa linhas ausentes; importa e cruza os registros disponíveis.
