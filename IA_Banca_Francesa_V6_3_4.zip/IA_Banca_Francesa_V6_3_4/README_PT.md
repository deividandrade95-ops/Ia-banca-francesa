# IA Banca Francesa V6.3.4

Correção de continuidade, escolha obrigatória e auditoria financeira.

- O teste atual começa em O2903, respeitando o último teste visível O3019.
- O próximo número é calculado pelo maior teste real do histórico, sem regressão para O2903.
- Todas as rodadas exigem escolha P ou G.
- Sem sinal da IA: escolha manual com stake mínima de €0,50.
- Com sinal confirmado: seguir G/P com stake maior, configurada em €5,00.
- Resultado N é neutro e não gera perda financeira.
- O histórico é mesclado por número, sem duplicar registros.
- Não inventa linhas ausentes; registros faltantes devem ser importados pelo JSON.

Instalação: substitua integralmente o conteúdo do index.html no GitHub Pages.
